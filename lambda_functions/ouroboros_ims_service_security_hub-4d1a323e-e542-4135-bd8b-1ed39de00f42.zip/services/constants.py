MS_RESPONSE_SCHEMA = {
    "cookies": ["cookie1", "cookie2"],
    "isBase64Encoded": "true|false",
    "statusCode": "statusCode,2xx-5xx",
    "headers": {"headername": "headervalue"},
    "data": [],
    "messages": []
}
